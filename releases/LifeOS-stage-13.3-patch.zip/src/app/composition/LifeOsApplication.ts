import type {
  ActionSessionRepository,
  Clock,
  CompleteCurrentDay,
  CompleteActionSession,
  CompleteLifeAction,
  VerifyLifeActionResult,
  CancelDecisionSafely,
  DeleteDecisionSafely,
  RestoreDeletedDecision,
  CancelLifeActionSafely,
  ConfirmDecisionFromActions,
  CreateDecisionForDate,
  CreateLifeActionForDecision,
  CurrentDateProvider,
  DayRepository,
  DecisionRepository,
  GetDecisionsForDate,
  GetDeletedDecisions,
  GetEveningReview,
  GetDecisionById,
  GetDecisionOverview,
  GetLifeActionsForDecision,
  GetHistoryForDateRange,
  GetActionListsForDate,
  GetLifeActionsForDate,
  GetActionSessionsForLifeAction,
  GetUnfinishedActionSession,
  GetOpenDayConflict,
  ResolveOpenDayConflict,
  IdGenerator,
  LifeActionRepository,
  PauseActionSession,
  ResumeActionSession,
  RescheduleDecisionSafely,
  RescheduleLifeActionSafely,
  StartCurrentDay,
  StartLifeActionSession,
  UpdateDecisionDetails,
  UpdateLifeActionDetails,
  RoutineBlockRepository,
  CreateRoutineBlock,
  UpdateRoutineBlock,
  DeleteRoutineBlock,
  GetRoutineBlocksForDate,
  GetRoutineActionOptions,
  GetRoutineActionDetails,
  RoutineOccurrenceOverrideRepository,
  DelayRoutineOccurrence,
  SkipRoutineOccurrence,
  RescheduleRoutineOccurrence,
  ShortenRoutineOccurrence,
  ReplaceRoutineOccurrenceAction,
  ClearRoutineOccurrenceOverride,
} from '../../application';
import { EnsureCurrentDay } from '../../application';
import type { Day, DayDate } from '../../domain';

interface LifeOsApplicationServices {
  readonly dayRepository: DayRepository;
  readonly decisionRepository: DecisionRepository;
  readonly lifeActionRepository: LifeActionRepository;
  readonly actionSessionRepository: ActionSessionRepository;
  readonly routineBlockRepository: RoutineBlockRepository;
  readonly routineOccurrenceOverrideRepository: RoutineOccurrenceOverrideRepository;
  readonly clock: Clock;
  readonly currentDateProvider: CurrentDateProvider;
  readonly idGenerator: IdGenerator;
  readonly ensureCurrentDay: EnsureCurrentDay;
  readonly currentDay: Day;
  readonly currentDate: DayDate;
  readonly startCurrentDay: StartCurrentDay;
  readonly getEveningReview: GetEveningReview;
  readonly completeCurrentDay: CompleteCurrentDay;
  readonly createDecisionForDate: CreateDecisionForDate;
  readonly getDecisionsForDate: GetDecisionsForDate;
  readonly getDeletedDecisions: GetDeletedDecisions;
  readonly getDecisionById: GetDecisionById;
  readonly getDecisionOverview: GetDecisionOverview;
  readonly getActionListsForDate: GetActionListsForDate;
  readonly getLifeActionsForDate: GetLifeActionsForDate;
  readonly getLifeActionsForDecision: GetLifeActionsForDecision;
  readonly getHistoryForDateRange: GetHistoryForDateRange;
  readonly createLifeActionForDecision: CreateLifeActionForDecision;
  readonly startLifeActionSession: StartLifeActionSession;
  readonly pauseActionSession: PauseActionSession;
  readonly resumeActionSession: ResumeActionSession;
  readonly completeActionSession: CompleteActionSession;
  readonly completeLifeAction: CompleteLifeAction;
  readonly verifyLifeActionResult: VerifyLifeActionResult;
  readonly confirmDecisionFromActions: ConfirmDecisionFromActions;
  readonly updateDecisionDetails: UpdateDecisionDetails;
  readonly cancelDecisionSafely: CancelDecisionSafely;
  readonly deleteDecisionSafely: DeleteDecisionSafely;
  readonly restoreDeletedDecision: RestoreDeletedDecision;
  readonly updateLifeActionDetails: UpdateLifeActionDetails;
  readonly cancelLifeActionSafely: CancelLifeActionSafely;
  readonly rescheduleDecisionSafely: RescheduleDecisionSafely;
  readonly rescheduleLifeActionSafely: RescheduleLifeActionSafely;
  readonly getActionSessionsForLifeAction: GetActionSessionsForLifeAction;
  readonly getUnfinishedActionSession: GetUnfinishedActionSession;
  readonly getOpenDayConflict: GetOpenDayConflict;
  readonly resolveOpenDayConflict: ResolveOpenDayConflict;
  readonly createRoutineBlock: CreateRoutineBlock;
  readonly updateRoutineBlock: UpdateRoutineBlock;
  readonly deleteRoutineBlock: DeleteRoutineBlock;
  readonly getRoutineBlocksForDate: GetRoutineBlocksForDate;
  readonly getRoutineActionOptions: GetRoutineActionOptions;
  readonly getRoutineActionDetails: GetRoutineActionDetails;
  readonly delayRoutineOccurrence: DelayRoutineOccurrence;
  readonly skipRoutineOccurrence: SkipRoutineOccurrence;
  readonly rescheduleRoutineOccurrence: RescheduleRoutineOccurrence;
  readonly shortenRoutineOccurrence: ShortenRoutineOccurrence;
  readonly replaceRoutineOccurrenceAction: ReplaceRoutineOccurrenceAction;
  readonly clearRoutineOccurrenceOverride: ClearRoutineOccurrenceOverride;
  readonly closeDatabase: () => void;
}

export class LifeOsApplication {
  public readonly dayRepository: DayRepository;
  public readonly decisionRepository: DecisionRepository;
  public readonly lifeActionRepository: LifeActionRepository;
  public readonly actionSessionRepository: ActionSessionRepository;
  public readonly routineBlockRepository: RoutineBlockRepository;
  public readonly routineOccurrenceOverrideRepository: RoutineOccurrenceOverrideRepository;
  public readonly clock: Clock;
  public readonly currentDateProvider: CurrentDateProvider;
  public readonly idGenerator: IdGenerator;
  public readonly ensureCurrentDay: EnsureCurrentDay;
  public readonly currentDay: Day;
  public readonly currentDate: DayDate;
  public readonly startCurrentDay: StartCurrentDay;
  public readonly getEveningReview: GetEveningReview;
  public readonly completeCurrentDay: CompleteCurrentDay;
  public readonly createDecisionForDate: CreateDecisionForDate;
  public readonly getDecisionsForDate: GetDecisionsForDate;
  public readonly getDeletedDecisions: GetDeletedDecisions;
  public readonly getDecisionById: GetDecisionById;
  public readonly getDecisionOverview: GetDecisionOverview;
  public readonly getActionListsForDate: GetActionListsForDate;
  public readonly getLifeActionsForDate: GetLifeActionsForDate;
  public readonly getLifeActionsForDecision: GetLifeActionsForDecision;
  public readonly getHistoryForDateRange: GetHistoryForDateRange;
  public readonly createLifeActionForDecision: CreateLifeActionForDecision;
  public readonly startLifeActionSession: StartLifeActionSession;
  public readonly pauseActionSession: PauseActionSession;
  public readonly resumeActionSession: ResumeActionSession;
  public readonly completeActionSession: CompleteActionSession;
  public readonly completeLifeAction: CompleteLifeAction;
  public readonly verifyLifeActionResult: VerifyLifeActionResult;
  public readonly confirmDecisionFromActions: ConfirmDecisionFromActions;
  public readonly updateDecisionDetails: UpdateDecisionDetails;
  public readonly cancelDecisionSafely: CancelDecisionSafely;
  public readonly deleteDecisionSafely: DeleteDecisionSafely;
  public readonly restoreDeletedDecision: RestoreDeletedDecision;
  public readonly updateLifeActionDetails: UpdateLifeActionDetails;
  public readonly cancelLifeActionSafely: CancelLifeActionSafely;
  public readonly rescheduleDecisionSafely: RescheduleDecisionSafely;
  public readonly rescheduleLifeActionSafely: RescheduleLifeActionSafely;
  public readonly getActionSessionsForLifeAction: GetActionSessionsForLifeAction;
  public readonly getUnfinishedActionSession: GetUnfinishedActionSession;
  public readonly getOpenDayConflict: GetOpenDayConflict;
  public readonly resolveOpenDayConflict: ResolveOpenDayConflict;
  public readonly createRoutineBlock: CreateRoutineBlock;
  public readonly updateRoutineBlock: UpdateRoutineBlock;
  public readonly deleteRoutineBlock: DeleteRoutineBlock;
  public readonly getRoutineBlocksForDate: GetRoutineBlocksForDate;
  public readonly getRoutineActionOptions: GetRoutineActionOptions;
  public readonly getRoutineActionDetails: GetRoutineActionDetails;
  public readonly delayRoutineOccurrence: DelayRoutineOccurrence;
  public readonly skipRoutineOccurrence: SkipRoutineOccurrence;
  public readonly rescheduleRoutineOccurrence: RescheduleRoutineOccurrence;
  public readonly shortenRoutineOccurrence: ShortenRoutineOccurrence;
  public readonly replaceRoutineOccurrenceAction: ReplaceRoutineOccurrenceAction;
  public readonly clearRoutineOccurrenceOverride: ClearRoutineOccurrenceOverride;

  readonly #closeDatabase: () => void;

  public constructor(services: LifeOsApplicationServices) {
    this.dayRepository = services.dayRepository;
    this.decisionRepository = services.decisionRepository;
    this.lifeActionRepository = services.lifeActionRepository;
    this.actionSessionRepository = services.actionSessionRepository;
    this.routineBlockRepository = services.routineBlockRepository;
    this.routineOccurrenceOverrideRepository = services.routineOccurrenceOverrideRepository;
    this.clock = services.clock;
    this.currentDateProvider = services.currentDateProvider;
    this.idGenerator = services.idGenerator;
    this.ensureCurrentDay = services.ensureCurrentDay;
    this.currentDay = services.currentDay;
    this.currentDate = services.currentDate;
    this.startCurrentDay = services.startCurrentDay;
    this.getEveningReview = services.getEveningReview;
    this.completeCurrentDay = services.completeCurrentDay;
    this.createDecisionForDate = services.createDecisionForDate;
    this.getDecisionsForDate = services.getDecisionsForDate;
    this.getDeletedDecisions = services.getDeletedDecisions;
    this.getDecisionById = services.getDecisionById;
    this.getDecisionOverview = services.getDecisionOverview;
    this.getActionListsForDate = services.getActionListsForDate;
    this.getLifeActionsForDate = services.getLifeActionsForDate;
    this.getLifeActionsForDecision = services.getLifeActionsForDecision;
    this.getHistoryForDateRange = services.getHistoryForDateRange;
    this.createLifeActionForDecision = services.createLifeActionForDecision;
    this.startLifeActionSession = services.startLifeActionSession;
    this.pauseActionSession = services.pauseActionSession;
    this.resumeActionSession = services.resumeActionSession;
    this.completeActionSession = services.completeActionSession;
    this.completeLifeAction = services.completeLifeAction;
    this.verifyLifeActionResult = services.verifyLifeActionResult;
    this.confirmDecisionFromActions = services.confirmDecisionFromActions;
    this.updateDecisionDetails = services.updateDecisionDetails;
    this.cancelDecisionSafely = services.cancelDecisionSafely;
    this.deleteDecisionSafely = services.deleteDecisionSafely;
    this.restoreDeletedDecision = services.restoreDeletedDecision;
    this.updateLifeActionDetails = services.updateLifeActionDetails;
    this.cancelLifeActionSafely = services.cancelLifeActionSafely;
    this.rescheduleDecisionSafely = services.rescheduleDecisionSafely;
    this.rescheduleLifeActionSafely = services.rescheduleLifeActionSafely;
    this.getActionSessionsForLifeAction = services.getActionSessionsForLifeAction;
    this.getUnfinishedActionSession = services.getUnfinishedActionSession;
    this.getOpenDayConflict = services.getOpenDayConflict;
    this.resolveOpenDayConflict = services.resolveOpenDayConflict;
    this.createRoutineBlock = services.createRoutineBlock;
    this.updateRoutineBlock = services.updateRoutineBlock;
    this.deleteRoutineBlock = services.deleteRoutineBlock;
    this.getRoutineBlocksForDate = services.getRoutineBlocksForDate;
    this.getRoutineActionOptions = services.getRoutineActionOptions;
    this.getRoutineActionDetails = services.getRoutineActionDetails;
    this.delayRoutineOccurrence = services.delayRoutineOccurrence;
    this.skipRoutineOccurrence = services.skipRoutineOccurrence;
    this.rescheduleRoutineOccurrence = services.rescheduleRoutineOccurrence;
    this.shortenRoutineOccurrence = services.shortenRoutineOccurrence;
    this.replaceRoutineOccurrenceAction = services.replaceRoutineOccurrenceAction;
    this.clearRoutineOccurrenceOverride = services.clearRoutineOccurrenceOverride;
    this.#closeDatabase = services.closeDatabase;
  }

  public close(): void {
    this.#closeDatabase();
  }
}
