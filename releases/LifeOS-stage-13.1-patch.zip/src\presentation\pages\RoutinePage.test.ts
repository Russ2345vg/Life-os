import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';
import {
  CreateRoutineBlock,
  DeleteRoutineBlock,
  GetRoutineBlocksForDate,
  UpdateRoutineBlock,
} from '../../application';
import {
  DayDate,
  EntityId,
  ROUTINE_BLOCK_CATEGORY,
  ROUTINE_BLOCK_RECURRENCE,
  RoutineBlock,
  RoutineBlockRecurrence,
} from '../../domain';
import { InMemoryRoutineBlockRepository } from '../../infrastructure';
import { FakeClock, FakeIdGenerator } from '../../test/helpers/Fakes';
import { RoutineBlockForm } from '../routine/RoutineBlockForm';
import { createEmptyRoutineBlockForm } from '../routine/RoutineBlockFormState';
import { findRoutineBlockOverlaps } from '../routine/RoutineBlockOverlaps';
import { RoutinePage } from './RoutinePage';

const DATE = DayDate.create('2026-08-08');

function block(id: string, title: string, startTime: string, endTime: string): RoutineBlock {
  return RoutineBlock.create({
    id: EntityId.create(id),
    anchorDate: DATE,
    title,
    startTime,
    endTime,
    category: ROUTINE_BLOCK_CATEGORY.work,
    recurrence: RoutineBlockRecurrence.create(ROUTINE_BLOCK_RECURRENCE.none),
    required: false,
    now: new Date('2026-08-08T00:00:00.000Z'),
  });
}

describe('RoutinePage', () => {
  it('renders the empty state and create action in the responsive section layout', () => {
    const repository = new InMemoryRoutineBlockRepository();
    const clock = new FakeClock(new Date('2026-08-08T00:00:00.000Z'));
    const markup = renderToStaticMarkup(
      createElement(RoutinePage, {
        currentDate: DATE,
        selectedDate: DATE,
        onDateChange: () => undefined,
        createRoutineBlock: new CreateRoutineBlock(repository, clock, new FakeIdGenerator()),
        updateRoutineBlock: new UpdateRoutineBlock(repository, clock),
        deleteRoutineBlock: new DeleteRoutineBlock(repository),
        getRoutineBlocksForDate: new GetRoutineBlocksForDate(repository),
      }),
    );
    expect(markup).toContain('routine-page');
    expect(markup).toContain('На этот день распорядок пока не составлен.');
    expect(markup.match(/Создать блок/g)?.length).toBe(2);
  });

  it('identifies and names conflicting intervals without blocking them', () => {
    const overlaps = findRoutineBlockOverlaps([
      block('one', 'Фокус', '09:00', '10:30'),
      block('two', 'Звонок', '10:00', '11:00'),
      block('three', 'Обед', '12:00', '13:00'),
    ]);
    expect(overlaps).toEqual(['09:00–10:30 «Фокус» и 10:00–11:00 «Звонок»']);
  });
});

describe('RoutineBlockForm', () => {
  it('renders every stage 13.1 field including weekday selection', () => {
    const form = {
      ...createEmptyRoutineBlockForm(DATE),
      recurrence: ROUTINE_BLOCK_RECURRENCE.selectedWeekdays,
      selectedWeekdays: [1, 3] as const,
    };
    const markup = renderToStaticMarkup(
      createElement(RoutineBlockForm, {
        form,
        errors: {},
        submitError: null,
        isEditing: false,
        isSaving: false,
        onChange: () => undefined,
        onCancel: () => undefined,
        onSubmit: () => undefined,
      }),
    );
    for (const label of [
      'Название',
      'Дата начала правила',
      'Категория',
      'Начало',
      'Окончание',
      'Повторяемость',
      'Дни недели',
      'Обязательный блок',
    ])
      expect(markup).toContain(label);
    expect(markup).toContain('Пн');
    expect(markup).toContain('Вс');
  });

  it('keeps a long title in the form and disables controls while saving', () => {
    const longTitle =
      'Очень длинное название блока распорядка, которое должно переноситься в узком окне без горизонтального переполнения';
    const form = {
      ...createEmptyRoutineBlockForm(DATE),
      title: longTitle,
      startTime: '09:00',
      endTime: '10:00',
    };
    const markup = renderToStaticMarkup(
      createElement(RoutineBlockForm, {
        form,
        errors: {},
        submitError: null,
        isEditing: true,
        isSaving: true,
        onChange: () => undefined,
        onCancel: () => undefined,
        onSubmit: () => undefined,
      }),
    );
    expect(markup).toContain(longTitle);
    expect(markup).toContain('routine-form-grid');
    expect(markup.match(/disabled=""/g)?.length).toBeGreaterThan(5);
    expect(markup).toContain('Сохраняем…');
  });
});
