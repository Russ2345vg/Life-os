import type { DayDate, RoutineBlock } from '../../domain';
import type { RoutineBlockRepository } from '../ports/RoutineBlockRepository';

export class GetRoutineBlocksForDate {
  public constructor(readonly repository: RoutineBlockRepository) {}

  public async execute(date: DayDate): Promise<readonly RoutineBlock[]> {
    const blocks = await this.repository.findAll();
    return blocks
      .filter((block) => block.occursOn(date))
      .sort(
        (left, right) =>
          left.startTime.localeCompare(right.startTime) ||
          left.endTime.localeCompare(right.endTime) ||
          left.id.toString().localeCompare(right.id.toString()),
      );
  }
}
