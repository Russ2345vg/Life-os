import { describe, expect, it } from 'vitest';
import { DayDate, ROUTINE_BLOCK_CATEGORY, ROUTINE_BLOCK_RECURRENCE } from '../../domain';
import { InMemoryRoutineBlockRepository } from '../../infrastructure';
import { FakeClock, FakeIdGenerator } from '../../test/helpers/Fakes';
import { CreateRoutineBlock } from './CreateRoutineBlock';
import { DeleteRoutineBlock } from './DeleteRoutineBlock';
import { UpdateRoutineBlock } from './UpdateRoutineBlock';
import { GetRoutineBlocksForDate } from '../queries/GetRoutineBlocksForDate';

const MONDAY = DayDate.create('2026-08-03');

function setup() {
  const repository = new InMemoryRoutineBlockRepository();
  const clock = new FakeClock(new Date('2026-08-03T00:00:00.000Z'));
  return {
    repository,
    clock,
    create: new CreateRoutineBlock(repository, clock, new FakeIdGenerator('routine')),
    update: new UpdateRoutineBlock(repository, clock),
    remove: new DeleteRoutineBlock(repository),
    query: new GetRoutineBlocksForDate(repository),
  };
}

function details(overrides: Partial<Parameters<CreateRoutineBlock['execute']>[0]> = {}) {
  return {
    anchorDate: MONDAY,
    title: 'Работа',
    startTime: '09:00',
    endTime: '10:00',
    category: ROUTINE_BLOCK_CATEGORY.work,
    recurrence: ROUTINE_BLOCK_RECURRENCE.none,
    required: true,
    ...overrides,
  };
}

describe('routine block commands', () => {
  it('creates a one-time block and returns it for anchorDate', async () => {
    const app = setup();
    const result = await app.create.execute(details());
    expect(result.ok).toBe(true);
    expect(await app.query.execute(MONDAY)).toHaveLength(1);
    expect(await app.query.execute(DayDate.create('2026-08-04'))).toHaveLength(0);
  });

  it.each([
    [{ title: ' ' }, 'routine_block.title_required'],
    [{ startTime: '' }, 'routine_block.start_time_required'],
    [{ endTime: '' }, 'routine_block.end_time_required'],
    [{ startTime: '10:00', endTime: '10:00' }, 'routine_block.invalid_time_range'],
  ])('does not persist invalid input', async (overrides, code) => {
    const app = setup();
    const result = await app.create.execute(details(overrides));
    expect(result).toMatchObject({ ok: false, error: { code } });
    expect(await app.repository.findAll()).toHaveLength(0);
  });

  it('calculates recurring appearances, respects anchorDate, and sorts by startTime', async () => {
    const app = setup();
    await app.create.execute(
      details({
        title: 'Позже',
        startTime: '10:00',
        endTime: '11:00',
        recurrence: ROUTINE_BLOCK_RECURRENCE.daily,
      }),
    );
    await app.create.execute(
      details({
        title: 'Раньше',
        startTime: '08:00',
        endTime: '09:00',
        recurrence: ROUTINE_BLOCK_RECURRENCE.selectedWeekdays,
        selectedWeekdays: [1, 3],
      }),
    );
    await app.create.execute(
      details({
        title: 'Будни',
        startTime: '12:00',
        endTime: '13:00',
        recurrence: ROUTINE_BLOCK_RECURRENCE.weekdays,
      }),
    );
    await app.create.execute(
      details({
        title: 'Выходные',
        startTime: '14:00',
        endTime: '15:00',
        recurrence: ROUTINE_BLOCK_RECURRENCE.weekends,
      }),
    );

    expect((await app.query.execute(MONDAY)).map((block) => block.title)).toEqual([
      'Раньше',
      'Позже',
      'Будни',
    ]);
    expect(
      (await app.query.execute(DayDate.create('2026-08-08'))).map((block) => block.title),
    ).toEqual(['Позже', 'Выходные']);
    expect(await app.query.execute(DayDate.create('2026-08-02'))).toHaveLength(0);
  });

  it('updates with expectedVersion', async () => {
    const app = setup();
    const created = await app.create.execute(details());
    if (!created.ok) throw created.error;
    const updated = await app.update.execute({
      ...details({ title: 'Новая работа' }),
      id: created.value.id,
      expectedVersion: 1,
    });
    expect(updated).toMatchObject({ ok: true, value: { title: 'Новая работа', version: 2 } });
  });

  it('preserves user data by rejecting a stale update', async () => {
    const app = setup();
    const created = await app.create.execute(details());
    if (!created.ok) throw created.error;
    await app.update.execute({
      ...details({ title: 'Свежая версия' }),
      id: created.value.id,
      expectedVersion: 1,
    });
    const stale = await app.update.execute({
      ...details({ title: 'Устаревшая версия' }),
      id: created.value.id,
      expectedVersion: 1,
    });
    expect(stale).toMatchObject({ ok: false, error: { code: 'routine_block.version_conflict' } });
    expect((await app.repository.findById(created.value.id))?.title).toBe('Свежая версия');
  });

  it('deletes only the routine block with matching version', async () => {
    const app = setup();
    const created = await app.create.execute(details());
    if (!created.ok) throw created.error;
    expect(await app.remove.execute({ id: created.value.id, expectedVersion: 1 })).toMatchObject({
      ok: true,
    });
    expect(await app.repository.findAll()).toHaveLength(0);
  });

  it('rejects stale deletion', async () => {
    const app = setup();
    const created = await app.create.execute(details());
    if (!created.ok) throw created.error;
    await app.update.execute({
      ...details({ title: 'Версия 2' }),
      id: created.value.id,
      expectedVersion: 1,
    });
    expect(await app.remove.execute({ id: created.value.id, expectedVersion: 1 })).toMatchObject({
      ok: false,
      error: { code: 'routine_block.version_conflict' },
    });
    expect(await app.repository.findAll()).toHaveLength(1);
  });
});
