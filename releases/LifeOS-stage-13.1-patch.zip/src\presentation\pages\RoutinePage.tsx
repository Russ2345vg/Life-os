import { useEffect, useRef, useState } from 'react';
import type {
  CreateRoutineBlock,
  DeleteRoutineBlock,
  GetRoutineBlocksForDate,
  UpdateRoutineBlock,
} from '../../application';
import { DayDate, type RoutineBlock } from '../../domain';
import { SectionDateNavigator } from '../components/SectionDateNavigator';
import { SectionPageHeader } from '../components/SectionPageHeader';
import { RoutineBlockForm } from '../routine/RoutineBlockForm';
import { ROUTINE_CATEGORY_LABELS, ROUTINE_RECURRENCE_LABELS } from '../routine/RoutineBlockLabels';
import {
  createEmptyRoutineBlockForm,
  createRoutineBlockEditForm,
  hasRoutineBlockFormErrors,
  validateRoutineBlockForm,
  type RoutineBlockFormErrors,
  type RoutineBlockFormState,
} from '../routine/RoutineBlockFormState';
import { RoutineSubmissionGuard } from '../routine/RoutineSubmissionGuard';
import { findRoutineBlockOverlaps } from '../routine/RoutineBlockOverlaps';

interface RoutinePageProps {
  readonly currentDate: DayDate;
  readonly selectedDate: DayDate;
  readonly onDateChange: (date: DayDate) => void;
  readonly createRoutineBlock: CreateRoutineBlock;
  readonly updateRoutineBlock: UpdateRoutineBlock;
  readonly deleteRoutineBlock: DeleteRoutineBlock;
  readonly getRoutineBlocksForDate: GetRoutineBlocksForDate;
}

export function RoutinePage(props: RoutinePageProps) {
  const [blocks, setBlocks] = useState<readonly RoutineBlock[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [form, setForm] = useState<RoutineBlockFormState | null>(null);
  const [editing, setEditing] = useState<RoutineBlock | null>(null);
  const [errors, setErrors] = useState<RoutineBlockFormErrors>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<RoutineBlock | null>(null);
  const savingGuard = useRef(new RoutineSubmissionGuard());

  useEffect(() => {
    let active = true;
    props.getRoutineBlocksForDate.execute(props.selectedDate).then(
      (nextBlocks) => {
        if (active) {
          setBlocks(nextBlocks);
          setLoadError(null);
        }
      },
      () => {
        if (active) setLoadError('Не удалось загрузить распорядок.');
      },
    );
    return () => {
      active = false;
    };
  }, [props.getRoutineBlocksForDate, props.selectedDate]);

  async function reload(): Promise<void> {
    setBlocks(await props.getRoutineBlocksForDate.execute(props.selectedDate));
    setLoadError(null);
  }

  function openCreate(): void {
    setEditing(null);
    setForm(createEmptyRoutineBlockForm(props.selectedDate));
    setErrors({});
    setSubmitError(null);
  }

  function openEdit(block: RoutineBlock): void {
    setEditing(block);
    setForm(createRoutineBlockEditForm(block));
    setErrors({});
    setSubmitError(null);
  }

  async function save(): Promise<void> {
    if (form === null) return;
    const nextErrors = validateRoutineBlockForm(form);
    setErrors(nextErrors);
    if (hasRoutineBlockFormErrors(nextErrors)) return;
    if (!savingGuard.current.tryAcquire()) return;
    setIsSaving(true);
    setSubmitError(null);
    try {
      const details = {
        anchorDate: DayDate.create(form.anchorDate),
        title: form.title,
        startTime: form.startTime,
        endTime: form.endTime,
        category: form.category,
        recurrence: form.recurrence,
        selectedWeekdays: form.selectedWeekdays,
        required: form.required,
      };
      const result =
        editing === null
          ? await props.createRoutineBlock.execute(details)
          : await props.updateRoutineBlock.execute({
              ...details,
              id: editing.id,
              expectedVersion: editing.version,
            });
      if (!result.ok) {
        setSubmitError(result.error.message);
        return;
      }
      setForm(null);
      setEditing(null);
      await reload();
    } catch {
      setSubmitError('Не удалось сохранить блок. Проверьте введённые значения.');
    } finally {
      savingGuard.current.release();
      setIsSaving(false);
    }
  }

  async function remove(): Promise<void> {
    if (deleteTarget === null || !savingGuard.current.tryAcquire()) return;
    setIsSaving(true);
    const result = await props.deleteRoutineBlock.execute({
      id: deleteTarget.id,
      expectedVersion: deleteTarget.version,
    });
    savingGuard.current.release();
    setIsSaving(false);
    if (!result.ok) {
      setSubmitError(result.error.message);
      setEditing(deleteTarget);
      setForm(createRoutineBlockEditForm(deleteTarget));
      setDeleteTarget(null);
      return;
    }
    setDeleteTarget(null);
    await reload();
  }

  const overlaps = findRoutineBlockOverlaps(blocks);

  return (
    <main className="section-page routine-page">
      <SectionPageHeader
        eyebrow="Этап 13.1"
        title="Распорядок"
        description="Плановые блоки дня и правила их повторения."
        action={
          <button className="primary-button" type="button" onClick={openCreate}>
            Создать блок
          </button>
        }
      />
      <SectionDateNavigator
        currentDate={props.currentDate}
        selectedDate={props.selectedDate}
        onDateChange={props.onDateChange}
      />
      {loadError === null ? null : (
        <p className="routine-message error" role="alert">
          {loadError}
        </p>
      )}
      {overlaps.length === 0 ? null : (
        <aside className="routine-overlap-warning" role="status">
          <strong>В распорядке есть пересечения</strong>
          <ul>
            {overlaps.map((overlap) => (
              <li key={overlap}>{overlap}</li>
            ))}
          </ul>
          <p>Сохранение разрешено: скорректируйте интервалы вручную, если это необходимо.</p>
        </aside>
      )}
      {blocks.length === 0 && loadError === null ? (
        <section className="routine-empty">
          <h2>На этот день распорядок пока не составлен.</h2>
          <button className="primary-button" type="button" onClick={openCreate}>
            Создать блок
          </button>
        </section>
      ) : (
        <section className="routine-list" aria-label="Блоки распорядка">
          {blocks.map((block) => (
            <article
              className={`routine-card routine-category-${block.category}`}
              key={block.id.toString()}
            >
              <div className="routine-card-time">
                <strong>{block.startTime}</strong>
                <span>—</span>
                <strong>{block.endTime}</strong>
              </div>
              <div className="routine-card-copy">
                <h2>{block.title}</h2>
                <div className="routine-card-badges">
                  <span>{ROUTINE_CATEGORY_LABELS[block.category]}</span>
                  <span>{block.required ? 'Обязательный' : 'Необязательный'}</span>
                  <span>{ROUTINE_RECURRENCE_LABELS[block.recurrence.kind]}</span>
                </div>
              </div>
              <div className="routine-card-actions">
                <button className="secondary-button" type="button" onClick={() => openEdit(block)}>
                  Изменить
                </button>
                <button
                  className="routine-delete-button"
                  type="button"
                  onClick={() => setDeleteTarget(block)}
                >
                  Удалить
                </button>
              </div>
            </article>
          ))}
        </section>
      )}
      {form === null ? null : (
        <RoutineBlockForm
          form={form}
          errors={errors}
          submitError={submitError}
          isEditing={editing !== null}
          isSaving={isSaving}
          onChange={setForm}
          onCancel={() => {
            if (!isSaving) setForm(null);
          }}
          onSubmit={() => void save()}
        />
      )}
      {deleteTarget === null ? null : (
        <div className="routine-form-backdrop" role="presentation">
          <section
            className="routine-delete-dialog"
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="routine-delete-title"
          >
            <h2 id="routine-delete-title">Удалить блок «{deleteTarget.title}»?</h2>
            <p>
              Правило будет удалено целиком. Дни, решения, действия и рабочие сессии не изменятся.
            </p>
            <div className="form-actions">
              <button
                className="secondary-button"
                type="button"
                disabled={isSaving}
                onClick={() => setDeleteTarget(null)}
              >
                Отмена
              </button>
              <button
                className="danger-button"
                type="button"
                disabled={isSaving}
                onClick={() => void remove()}
              >
                {isSaving ? 'Удаляем…' : 'Удалить блок'}
              </button>
            </div>
          </section>
        </div>
      )}
    </main>
  );
}
