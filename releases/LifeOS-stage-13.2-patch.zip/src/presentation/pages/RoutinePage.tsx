import { useEffect, useRef, useState } from 'react';
import type {
  CancelDecisionSafely,
  CancelLifeActionSafely,
  Clock,
  CompleteActionSession,
  CompleteCurrentDay,
  CompleteLifeAction,
  ConfirmDecisionFromActions,
  CreateLifeActionForDecision,
  CreateRoutineBlock,
  DeleteRoutineBlock,
  GetActionSessionsForLifeAction,
  GetDecisionById,
  GetDecisionOverview,
  GetDecisionsForDate,
  GetEveningReview,
  GetLifeActionsForDecision,
  GetRoutineActionDetails,
  GetRoutineActionOptions,
  GetRoutineBlocksForDate,
  GetUnfinishedActionSession,
  PauseActionSession,
  RescheduleDecisionSafely,
  RescheduleLifeActionSafely,
  ResumeActionSession,
  RoutineActionDetails,
  RoutineActionOption,
  StartLifeActionSession,
  UpdateDecisionDetails,
  UpdateLifeActionDetails,
  UpdateRoutineBlock,
} from '../../application';
import {
  DAY_STATUS,
  DECISION_STATUS,
  DayDate,
  EntityId,
  LIFE_ACTION_STATUS,
  ROUTINE_BLOCK_ASSIGNMENT,
  type Day,
  type Decision,
  type LifeAction,
  type RoutineBlock,
  type RoutineBlockAssignmentKind,
} from '../../domain';
import { DecisionDetailsController } from '../components/DecisionDetailsController';
import { LifeActionDetailsController } from '../components/LifeActionDetailsController';
import { SectionDateNavigator } from '../components/SectionDateNavigator';
import { SectionPageHeader } from '../components/SectionPageHeader';
import { RoutineBlockForm } from '../routine/RoutineBlockForm';
import {
  ROUTINE_ASSIGNMENT_LABELS,
  ROUTINE_CATEGORY_LABELS,
  ROUTINE_RECURRENCE_LABELS,
} from '../routine/RoutineBlockLabels';
import {
  createEmptyRoutineBlockForm,
  createRoutineBlockEditForm,
  hasRoutineBlockFormErrors,
  validateRoutineBlockForm,
  type RoutineBlockFormErrors,
  type RoutineBlockFormState,
} from '../routine/RoutineBlockFormState';
import { RoutineSubmissionGuard } from '../routine/RoutineSubmissionGuard';
import { findRoutineBlockOverlaps } from '../routine/RoutineBlockOverlaps';
import { EveningReviewPanel } from './EveningReviewPanel';

interface RoutinePageProps {
  readonly currentDate: DayDate;
  readonly selectedDate: DayDate;
  readonly onDateChange: (date: DayDate) => void;
  readonly onCurrentDayChange?: (day: Day) => void;
  readonly createRoutineBlock: CreateRoutineBlock;
  readonly updateRoutineBlock: UpdateRoutineBlock;
  readonly deleteRoutineBlock: DeleteRoutineBlock;
  readonly getRoutineBlocksForDate: GetRoutineBlocksForDate;
  readonly workflow?: RoutinePageWorkflowServices;
}

export interface RoutinePageWorkflowServices {
  readonly getRoutineActionOptions: GetRoutineActionOptions;
  readonly getRoutineActionDetails: GetRoutineActionDetails;
  readonly getDecisionsForDate: Pick<GetDecisionsForDate, 'execute'>;
  readonly getEveningReview: Pick<GetEveningReview, 'execute'>;
  readonly completeCurrentDay: Pick<CompleteCurrentDay, 'execute'>;
  readonly getDecisionById: Pick<GetDecisionById, 'execute'>;
  readonly getDecisionOverview: Pick<GetDecisionOverview, 'execute'>;
  readonly getLifeActionsForDecision: Pick<GetLifeActionsForDecision, 'execute'>;
  readonly createLifeActionForDecision: Pick<CreateLifeActionForDecision, 'execute'>;
  readonly confirmDecisionFromActions: Pick<ConfirmDecisionFromActions, 'execute'>;
  readonly updateDecisionDetails: Pick<UpdateDecisionDetails, 'execute'>;
  readonly cancelDecisionSafely: Pick<CancelDecisionSafely, 'execute'>;
  readonly rescheduleDecisionSafely: Pick<RescheduleDecisionSafely, 'execute'>;
  readonly getActionSessionsForLifeAction: Pick<GetActionSessionsForLifeAction, 'execute'>;
  readonly getUnfinishedActionSession: Pick<GetUnfinishedActionSession, 'execute'>;
  readonly startLifeActionSession: Pick<StartLifeActionSession, 'execute'>;
  readonly pauseActionSession: Pick<PauseActionSession, 'execute'>;
  readonly resumeActionSession: Pick<ResumeActionSession, 'execute'>;
  readonly completeActionSession: Pick<CompleteActionSession, 'execute'>;
  readonly completeLifeAction: Pick<CompleteLifeAction, 'execute'>;
  readonly updateLifeActionDetails: Pick<UpdateLifeActionDetails, 'execute'>;
  readonly cancelLifeActionSafely: Pick<CancelLifeActionSafely, 'execute'>;
  readonly rescheduleLifeActionSafely: Pick<RescheduleLifeActionSafely, 'execute'>;
  readonly clock: Pick<Clock, 'now'>;
}

interface PendingActionLink {
  readonly block: RoutineBlock;
  readonly lifeAction: LifeAction;
}

export function RoutinePage(props: RoutinePageProps) {
  const workflow = props.workflow;
  const [blocks, setBlocks] = useState<readonly RoutineBlock[]>([]);
  const [actionOptions, setActionOptions] = useState<readonly RoutineActionOption[]>([]);
  const [actionDetails, setActionDetails] = useState<
    ReadonlyMap<string, RoutineActionDetails | null>
  >(new Map());
  const [loadError, setLoadError] = useState<string | null>(null);
  const [form, setForm] = useState<RoutineBlockFormState | null>(null);
  const [editing, setEditing] = useState<RoutineBlock | null>(null);
  const [errors, setErrors] = useState<RoutineBlockFormErrors>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<RoutineBlock | null>(null);
  const [reminderBlock, setReminderBlock] = useState<RoutineBlock | null>(null);
  const [selectedAction, setSelectedAction] = useState<LifeAction | null>(null);
  const [eveningReviewDate, setEveningReviewDate] = useState<DayDate | null>(null);
  const [activationMessage, setActivationMessage] = useState<string | null>(null);
  const [createTarget, setCreateTarget] = useState<RoutineBlock | null>(null);
  const [creationDecisions, setCreationDecisions] = useState<readonly Decision[]>([]);
  const [creationDecision, setCreationDecision] = useState<Decision | null>(null);
  const [pendingLink, setPendingLink] = useState<PendingActionLink | null>(null);
  const savingGuard = useRef(new RoutineSubmissionGuard());
  const activationGuard = useRef(new RoutineSubmissionGuard());

  useEffect(() => {
    let active = true;
    void Promise.all([
      props.getRoutineBlocksForDate.execute(props.selectedDate),
      workflow?.getRoutineActionOptions.execute() ?? Promise.resolve([]),
    ]).then(
      async ([nextBlocks, nextOptions]) => {
        const nextDetails =
          workflow === undefined
            ? new Map<string, RoutineActionDetails | null>()
            : await resolveActionDetails(nextBlocks, workflow.getRoutineActionDetails);
        if (!active) return;
        setBlocks(nextBlocks);
        setActionOptions(nextOptions);
        setActionDetails(nextDetails);
        setLoadError(null);
      },
      () => {
        if (active) setLoadError('Не удалось загрузить распорядок.');
      },
    );
    return () => {
      active = false;
    };
  }, [workflow, props.getRoutineBlocksForDate, props.selectedDate]);

  async function reload(): Promise<void> {
    const [nextBlocks, nextOptions] = await Promise.all([
      props.getRoutineBlocksForDate.execute(props.selectedDate),
      workflow?.getRoutineActionOptions.execute() ?? Promise.resolve([]),
    ]);
    setBlocks(nextBlocks);
    setActionOptions(nextOptions);
    setActionDetails(
      workflow === undefined
        ? new Map()
        : await resolveActionDetails(nextBlocks, workflow.getRoutineActionDetails),
    );
    setLoadError(null);
  }

  function openCreate(): void {
    setEditing(null);
    setForm(createEmptyRoutineBlockForm(props.selectedDate));
    setErrors({});
    setSubmitError(null);
  }

  function openEdit(block: RoutineBlock): void {
    setEditing(block);
    setForm(createRoutineBlockEditForm(block));
    setErrors({});
    setSubmitError(null);
  }

  async function save(): Promise<void> {
    if (form === null) return;
    const nextErrors = validateRoutineBlockForm(form);
    setErrors(nextErrors);
    if (hasRoutineBlockFormErrors(nextErrors)) return;
    if (!savingGuard.current.tryAcquire()) return;
    setIsSaving(true);
    setSubmitError(null);
    try {
      const details = formToCommandInput(form);
      const result =
        editing === null
          ? await props.createRoutineBlock.execute(details)
          : await props.updateRoutineBlock.execute({
              ...details,
              id: editing.id,
              expectedVersion: editing.version,
            });
      if (!result.ok) {
        setSubmitError(result.error.message);
        return;
      }
      setForm(null);
      setEditing(null);
      await reload();
    } catch {
      setSubmitError('Не удалось сохранить блок. Проверьте введённые значения.');
    } finally {
      savingGuard.current.release();
      setIsSaving(false);
    }
  }

  async function remove(): Promise<void> {
    if (deleteTarget === null || !savingGuard.current.tryAcquire()) return;
    setIsSaving(true);
    const result = await props.deleteRoutineBlock.execute({
      id: deleteTarget.id,
      expectedVersion: deleteTarget.version,
    });
    savingGuard.current.release();
    setIsSaving(false);
    if (!result.ok) {
      setSubmitError(result.error.message);
      setEditing(deleteTarget);
      setForm(createRoutineBlockEditForm(deleteTarget));
      setDeleteTarget(null);
      return;
    }
    setDeleteTarget(null);
    await reload();
  }

  async function activate(block: RoutineBlock): Promise<void> {
    if (!activationGuard.current.tryAcquire()) return;
    try {
      switch (block.assignment.kind) {
        case ROUTINE_BLOCK_ASSIGNMENT.reminder:
          setReminderBlock(block);
          return;
        case ROUTINE_BLOCK_ASSIGNMENT.existingAction: {
          if (workflow === undefined) {
            openEdit(block);
            return;
          }
          const details =
            actionDetails.get(block.assignment.actionId.toString()) ??
            (await workflow.getRoutineActionDetails.execute(block.assignment.actionId));
          if (details === null) {
            setActivationMessage(
              'Связанное действие больше недоступно. Измените назначение блока или выберите другое действие.',
            );
            openEdit(block);
            return;
          }
          setSelectedAction(details.lifeAction);
          return;
        }
        case ROUTINE_BLOCK_ASSIGNMENT.createAction: {
          if (workflow === undefined) return;
          if (props.selectedDate.isBefore(props.currentDate)) {
            setActivationMessage('Создание действия для прошедшей даты недоступно.');
            return;
          }
          const decisions = (await workflow.getDecisionsForDate.execute(props.selectedDate)).filter(
            canCreateActionForDecision,
          );
          setCreateTarget(block);
          setCreationDecisions(decisions);
          return;
        }
        case ROUTINE_BLOCK_ASSIGNMENT.eveningReview: {
          if (workflow === undefined) return;
          try {
            const snapshot = await workflow.getEveningReview.execute(props.selectedDate);
            if (snapshot.day.status === DAY_STATUS.completed) {
              setActivationMessage('День уже завершён. Вечерний контроль доступен в истории дня.');
              return;
            }
            if (snapshot.day.status !== DAY_STATUS.open) {
              setActivationMessage('Вечерний контроль доступен только после начала дня.');
              return;
            }
            setEveningReviewDate(props.selectedDate);
          } catch (error: unknown) {
            setActivationMessage(
              error instanceof Error
                ? error.message
                : 'Вечерний контроль для этой даты недоступен.',
            );
          }
          return;
        }
        case ROUTINE_BLOCK_ASSIGNMENT.walk:
          setActivationMessage(
            'Прогулки будут доступны после реализации раздела «Прогулки» на этапе 14.',
          );
      }
    } finally {
      activationGuard.current.release();
    }
  }

  async function confirmCreatedActionLink(): Promise<void> {
    if (pendingLink === null || !savingGuard.current.tryAcquire()) return;
    setIsSaving(true);
    const result = await props.updateRoutineBlock.execute({
      ...blockToCommandInput(pendingLink.block),
      assignmentKind: ROUTINE_BLOCK_ASSIGNMENT.existingAction,
      actionId: pendingLink.lifeAction.id,
      id: pendingLink.block.id,
      expectedVersion: pendingLink.block.version,
    });
    savingGuard.current.release();
    setIsSaving(false);
    if (!result.ok) {
      setActivationMessage(result.error.message);
      return;
    }
    setPendingLink(null);
    await reload();
  }

  const overlaps = findRoutineBlockOverlaps(blocks);
  const unavailableActionLabel =
    editing?.assignment.kind === ROUTINE_BLOCK_ASSIGNMENT.existingAction
      ? describeUnavailableAction(actionDetails.get(editing.assignment.actionId.toString()) ?? null)
      : undefined;

  return (
    <main className="section-page routine-page">
      <SectionPageHeader
        eyebrow="Этап 13.2"
        title="Распорядок"
        description="Плановые блоки дня, повторения и связь с реальными действиями."
        action={
          <button className="primary-button" type="button" onClick={openCreate}>
            Создать блок
          </button>
        }
      />
      <SectionDateNavigator
        currentDate={props.currentDate}
        selectedDate={props.selectedDate}
        onDateChange={props.onDateChange}
      />
      {loadError === null ? null : (
        <p className="routine-message error" role="alert">
          {loadError}
        </p>
      )}
      {overlaps.length === 0 ? null : (
        <aside className="routine-overlap-warning" role="status">
          <strong>В распорядке есть пересечения</strong>
          <ul>
            {overlaps.map((overlap) => (
              <li key={overlap}>{overlap}</li>
            ))}
          </ul>
          <p>Сохранение разрешено: скорректируйте интервалы вручную, если это необходимо.</p>
        </aside>
      )}
      {blocks.length === 0 && loadError === null ? (
        <section className="routine-empty">
          <h2>На этот день распорядок пока не составлен.</h2>
          <button className="primary-button" type="button" onClick={openCreate}>
            Создать блок
          </button>
        </section>
      ) : (
        <section className="routine-list" aria-label="Блоки распорядка">
          {blocks.map((block) => {
            const details = actionDetailsForBlock(block, actionDetails);
            return (
              <article
                className={`routine-card routine-category-${block.category}`}
                key={block.id.toString()}
              >
                <div className="routine-card-time">
                  <strong>{block.startTime}</strong>
                  <span>—</span>
                  <strong>{block.endTime}</strong>
                </div>
                <div className="routine-card-copy">
                  <p className="routine-card-purpose">{assignmentTitle(block, details)}</p>
                  <h2>{block.title}</h2>
                  {details?.decision == null ? null : (
                    <p className="routine-card-context">
                      Решение: {details.decision.title.toString()}
                    </p>
                  )}
                  {block.assignment.kind === ROUTINE_BLOCK_ASSIGNMENT.existingAction ? (
                    <p className="routine-card-context">
                      {details == null
                        ? 'Связанное действие недоступно'
                        : `Состояние: ${lifeActionStatusLabel(details.lifeAction)}`}
                    </p>
                  ) : null}
                  <div className="routine-card-badges">
                    <span>{ROUTINE_CATEGORY_LABELS[block.category]}</span>
                    <span>{block.required ? 'Обязательный' : 'Необязательный'}</span>
                    <span>{ROUTINE_RECURRENCE_LABELS[block.recurrence.kind]}</span>
                  </div>
                </div>
                <div className="routine-card-actions">
                  <button
                    className="primary-button routine-primary-command"
                    type="button"
                    onClick={() =>
                      details === null &&
                      block.assignment.kind === ROUTINE_BLOCK_ASSIGNMENT.existingAction
                        ? openEdit(block)
                        : void activate(block)
                    }
                  >
                    {primaryCommandLabel(block, details)}
                  </button>
                  <button
                    className="secondary-button"
                    type="button"
                    onClick={() => openEdit(block)}
                  >
                    Изменить
                  </button>
                  <button
                    className="routine-delete-button"
                    type="button"
                    onClick={() => setDeleteTarget(block)}
                  >
                    Удалить
                  </button>
                </div>
              </article>
            );
          })}
        </section>
      )}
      {form === null ? null : (
        <RoutineBlockForm
          form={form}
          errors={errors}
          submitError={submitError}
          isEditing={editing !== null}
          isSaving={isSaving}
          actionOptions={actionOptions}
          {...(unavailableActionLabel === undefined ? {} : { unavailableActionLabel })}
          onChange={setForm}
          onCancel={() => {
            if (!isSaving) setForm(null);
          }}
          onSubmit={() => void save()}
        />
      )}
      {deleteTarget === null ? null : (
        <RoutineDialog
          title={`Удалить блок «${deleteTarget.title}»?`}
          onClose={() => setDeleteTarget(null)}
        >
          <p>Правило будет удалено целиком. Решения, действия и рабочие сессии не изменятся.</p>
          <div className="form-actions">
            <button
              className="secondary-button"
              type="button"
              disabled={isSaving}
              onClick={() => setDeleteTarget(null)}
            >
              Отмена
            </button>
            <button
              className="danger-button"
              type="button"
              disabled={isSaving}
              onClick={() => void remove()}
            >
              {isSaving ? 'Удаляем…' : 'Удалить блок'}
            </button>
          </div>
        </RoutineDialog>
      )}
      {reminderBlock === null ? null : (
        <RoutineDialog
          title={`Напоминание · ${reminderBlock.title}`}
          onClose={() => setReminderBlock(null)}
        >
          <p>
            {reminderBlock.startTime}–{reminderBlock.endTime}
          </p>
          <p>Нажатие открыло только сведения о блоке. Предметные данные не изменены.</p>
        </RoutineDialog>
      )}
      {activationMessage === null ? null : (
        <RoutineDialog title="Назначение блока" onClose={() => setActivationMessage(null)}>
          <p>{activationMessage}</p>
        </RoutineDialog>
      )}
      {createTarget === null || creationDecision !== null ? null : (
        <RoutineDialog title="Создать действие" onClose={() => setCreateTarget(null)}>
          <p>Выберите решение. Откроется существующая форма создания действия для даты блока.</p>
          {creationDecisions.length === 0 ? (
            <p className="routine-message">
              На эту дату нет решения, для которого можно создать действие.
            </p>
          ) : (
            <div className="routine-decision-options">
              {creationDecisions.map((decision) => (
                <button
                  className="secondary-button"
                  type="button"
                  key={decision.id.toString()}
                  onClick={() => setCreationDecision(decision)}
                >
                  <strong>{decision.title.toString()}</strong>
                  <span>
                    {decision.expectedResult?.toString() ?? 'Ожидаемый результат не указан'}
                  </span>
                </button>
              ))}
            </div>
          )}
        </RoutineDialog>
      )}
      {workflow === undefined ? null : (
        <DecisionDetailsController
          decision={creationDecision}
          currentDate={props.currentDate}
          selectedDate={props.selectedDate}
          readOnly={false}
          getDecisionById={workflow.getDecisionById}
          getDecisionOverview={workflow.getDecisionOverview}
          getLifeActionsForDecision={workflow.getLifeActionsForDecision}
          createLifeActionForDecision={workflow.createLifeActionForDecision}
          confirmDecisionFromActions={workflow.confirmDecisionFromActions}
          updateDecisionDetails={workflow.updateDecisionDetails}
          cancelDecisionSafely={workflow.cancelDecisionSafely}
          rescheduleDecisionSafely={workflow.rescheduleDecisionSafely}
          getActionSessionsForLifeAction={workflow.getActionSessionsForLifeAction}
          getUnfinishedActionSession={workflow.getUnfinishedActionSession}
          startLifeActionSession={workflow.startLifeActionSession}
          pauseActionSession={workflow.pauseActionSession}
          resumeActionSession={workflow.resumeActionSession}
          completeActionSession={workflow.completeActionSession}
          completeLifeAction={workflow.completeLifeAction}
          updateLifeActionDetails={workflow.updateLifeActionDetails}
          cancelLifeActionSafely={workflow.cancelLifeActionSafely}
          rescheduleLifeActionSafely={workflow.rescheduleLifeActionSafely}
          clock={workflow.clock}
          initialLifeActionFormOpen
          onClose={() => {
            setCreationDecision(null);
            setCreateTarget(null);
          }}
          onDecisionChanged={setCreationDecision}
          onLifeActionCreated={(lifeAction) => {
            if (createTarget !== null) setPendingLink({ block: createTarget, lifeAction });
            setCreationDecision(null);
            setCreateTarget(null);
          }}
        />
      )}
      {pendingLink === null ? null : (
        <RoutineDialog title="Действие создано" onClose={() => setPendingLink(null)}>
          <p>
            Связать созданное действие «{pendingLink.lifeAction.title.toString()}» с этим блоком?
          </p>
          <div className="form-actions">
            <button
              className="secondary-button"
              type="button"
              disabled={isSaving}
              onClick={() => setPendingLink(null)}
            >
              Не связывать
            </button>
            <button
              className="primary-button"
              type="button"
              disabled={isSaving}
              onClick={() => void confirmCreatedActionLink()}
            >
              {isSaving ? 'Связываем…' : 'Связать действие'}
            </button>
          </div>
        </RoutineDialog>
      )}
      {selectedAction === null || workflow === undefined ? null : (
        <LifeActionDetailsController
          lifeAction={selectedAction}
          currentDate={props.currentDate}
          readOnly={selectedAction.plannedDate?.isBefore(props.currentDate) ?? false}
          clock={workflow.clock}
          getDecisionById={workflow.getDecisionById}
          getActionSessionsForLifeAction={workflow.getActionSessionsForLifeAction}
          getUnfinishedActionSession={workflow.getUnfinishedActionSession}
          startLifeActionSession={workflow.startLifeActionSession}
          pauseActionSession={workflow.pauseActionSession}
          resumeActionSession={workflow.resumeActionSession}
          completeActionSession={workflow.completeActionSession}
          completeLifeAction={workflow.completeLifeAction}
          updateLifeActionDetails={workflow.updateLifeActionDetails}
          cancelLifeActionSafely={workflow.cancelLifeActionSafely}
          rescheduleLifeActionSafely={workflow.rescheduleLifeActionSafely}
          backLabel="Назад к распорядку"
          onClose={() => setSelectedAction(null)}
          onActionChanged={(lifeAction) => {
            setSelectedAction(lifeAction);
            void reload();
          }}
        />
      )}
      {eveningReviewDate === null || workflow === undefined ? null : (
        <EveningReviewPanel
          getEveningReview={workflow.getEveningReview}
          completeCurrentDay={workflow.completeCurrentDay}
          reviewDate={eveningReviewDate}
          onClose={() => setEveningReviewDate(null)}
          onCompleted={(result) => {
            if (result.day.date.equals(props.currentDate)) props.onCurrentDayChange?.(result.day);
            setEveningReviewDate(null);
          }}
        />
      )}
    </main>
  );
}

async function resolveActionDetails(
  blocks: readonly RoutineBlock[],
  query: Pick<GetRoutineActionDetails, 'execute'>,
): Promise<ReadonlyMap<string, RoutineActionDetails | null>> {
  const ids = [
    ...new Set(
      blocks.flatMap((block) =>
        block.assignment.kind === ROUTINE_BLOCK_ASSIGNMENT.existingAction
          ? [block.assignment.actionId.toString()]
          : [],
      ),
    ),
  ];
  const entries = await Promise.all(
    ids.map(async (id) => [id, await query.execute(EntityId.create(id))] as const),
  );
  return new Map(entries);
}

function actionDetailsForBlock(
  block: RoutineBlock,
  details: ReadonlyMap<string, RoutineActionDetails | null>,
): RoutineActionDetails | null | undefined {
  return block.assignment.kind === ROUTINE_BLOCK_ASSIGNMENT.existingAction
    ? details.get(block.assignment.actionId.toString())
    : undefined;
}

function assignmentTitle(
  block: RoutineBlock,
  details: RoutineActionDetails | null | undefined,
): string {
  if (block.assignment.kind === ROUTINE_BLOCK_ASSIGNMENT.existingAction) {
    return details === null || details === undefined
      ? 'Действие · недоступно'
      : `Действие · ${details.lifeAction.title.toString()}`;
  }
  return ROUTINE_ASSIGNMENT_LABELS[block.assignment.kind];
}

function primaryCommandLabel(
  block: RoutineBlock,
  details: RoutineActionDetails | null | undefined,
): string {
  switch (block.assignment.kind) {
    case ROUTINE_BLOCK_ASSIGNMENT.reminder:
      return 'Открыть';
    case ROUTINE_BLOCK_ASSIGNMENT.existingAction:
      return details === null || details === undefined ? 'Изменить назначение' : 'Открыть действие';
    case ROUTINE_BLOCK_ASSIGNMENT.createAction:
      return 'Создать действие';
    case ROUTINE_BLOCK_ASSIGNMENT.eveningReview:
      return 'Открыть вечерний контроль';
    case ROUTINE_BLOCK_ASSIGNMENT.walk:
      return 'Прогулка пока недоступна';
  }
}

function lifeActionStatusLabel(action: LifeAction): string {
  switch (action.status) {
    case LIFE_ACTION_STATUS.draft:
      return 'черновик';
    case LIFE_ACTION_STATUS.ready:
      return 'готово';
    case LIFE_ACTION_STATUS.inProgress:
      return 'выполняется';
    case LIFE_ACTION_STATUS.completed:
      return 'завершено';
    case LIFE_ACTION_STATUS.cancelled:
      return 'отменено';
  }
}

function canCreateActionForDecision(decision: Decision): boolean {
  return (
    !decision.isArchived() &&
    !decision.isDeleted() &&
    (decision.status === DECISION_STATUS.draft ||
      decision.status === DECISION_STATUS.planned ||
      decision.status === DECISION_STATUS.inProgress)
  );
}

function formToCommandInput(form: RoutineBlockFormState) {
  return {
    anchorDate: DayDate.create(form.anchorDate),
    title: form.title,
    startTime: form.startTime,
    endTime: form.endTime,
    category: form.category,
    recurrence: form.recurrence,
    selectedWeekdays: form.selectedWeekdays,
    required: form.required,
    assignmentKind: form.assignmentKind,
    ...(form.assignmentKind === ROUTINE_BLOCK_ASSIGNMENT.existingAction
      ? { actionId: EntityId.create(form.actionId) }
      : {}),
  };
}

function blockToCommandInput(block: RoutineBlock) {
  return {
    anchorDate: block.anchorDate,
    title: block.title,
    startTime: block.startTime,
    endTime: block.endTime,
    category: block.category,
    recurrence: block.recurrence.kind,
    selectedWeekdays: block.recurrence.selectedWeekdays,
    required: block.required,
    assignmentKind: block.assignment.kind as RoutineBlockAssignmentKind,
    ...(block.assignment.kind === ROUTINE_BLOCK_ASSIGNMENT.existingAction
      ? { actionId: block.assignment.actionId }
      : {}),
  };
}

function describeUnavailableAction(details: RoutineActionDetails | null): string {
  return details === null
    ? 'Ранее связанное действие недоступно'
    : `${details.lifeAction.title.toString()} · ${lifeActionStatusLabel(details.lifeAction)}`;
}

interface RoutineDialogProps {
  readonly title: string;
  readonly children: React.ReactNode;
  readonly onClose: () => void;
}

function RoutineDialog({ title, children, onClose }: RoutineDialogProps) {
  return (
    <div className="routine-form-backdrop" role="presentation">
      <section className="routine-delete-dialog" role="dialog" aria-modal="true" aria-label={title}>
        <h2>{title}</h2>
        {children}
        <button className="secondary-button routine-dialog-close" type="button" onClick={onClose}>
          Закрыть
        </button>
      </section>
    </div>
  );
}
