import type { RoutineOccurrenceExecution } from '../../domain';
import type { RoutineOccurrenceExecutionRepository } from '../ports/RoutineOccurrenceExecutionRepository';

export class GetRunningRoutineOccurrence {
  public constructor(readonly repository: RoutineOccurrenceExecutionRepository) {}

  public execute(): Promise<RoutineOccurrenceExecution | null> {
    return this.repository.findRunning();
  }
}
